package sample;

public class Player {
    private String name;
    private int highestScore;
    private int lastGameScore;

    public Player(String name, int highestScore, int lastGameScore) {
        this.name = name;
        this.highestScore = highestScore;
        this.lastGameScore = lastGameScore;
    }

}
